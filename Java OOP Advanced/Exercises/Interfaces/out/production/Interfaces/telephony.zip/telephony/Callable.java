package telephony;

public interface Callable {

    String calling(String phoneNumber);
}
