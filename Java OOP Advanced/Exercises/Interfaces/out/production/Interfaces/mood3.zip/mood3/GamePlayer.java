package mood3;

public interface GamePlayer {
}
