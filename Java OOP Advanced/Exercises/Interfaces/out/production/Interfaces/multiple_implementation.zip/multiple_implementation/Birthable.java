package multiple_implementation;

public interface Birthable {

    String getBirthdate();
}
