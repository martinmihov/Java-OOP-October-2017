package collection_hierarchy;

public interface MyList<T> {

    int addFirst(T element);

    T removeFirst();

    int size();
}
