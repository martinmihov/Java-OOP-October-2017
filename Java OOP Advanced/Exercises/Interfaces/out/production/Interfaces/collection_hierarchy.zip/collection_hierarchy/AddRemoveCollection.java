package collection_hierarchy;

public interface AddRemoveCollection<T> {

    int addFirst(T element);

    T remove();
}
