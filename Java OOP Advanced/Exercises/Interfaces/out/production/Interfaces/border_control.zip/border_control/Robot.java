package border_control;

public class Robot extends Resident {

    private String model;

    public Robot(String id, String model) {
        super(id);
        this.model = model;
    }

    
}
