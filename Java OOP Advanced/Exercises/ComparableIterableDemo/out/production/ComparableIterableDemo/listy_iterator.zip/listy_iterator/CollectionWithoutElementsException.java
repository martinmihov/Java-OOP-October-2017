package listy_iterator;

public class CollectionWithoutElementsException extends IllegalStateException {

    public CollectionWithoutElementsException(String s) {
        super(s);
    }
}
