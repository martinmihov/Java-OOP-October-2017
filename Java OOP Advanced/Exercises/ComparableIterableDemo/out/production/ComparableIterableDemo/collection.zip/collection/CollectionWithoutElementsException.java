package collection;

public class CollectionWithoutElementsException extends IllegalStateException {

    public CollectionWithoutElementsException(String s) {
        super(s);
    }
}
