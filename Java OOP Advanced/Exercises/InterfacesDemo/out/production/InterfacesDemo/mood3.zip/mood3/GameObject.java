package mood3;

public interface GameObject {
}
