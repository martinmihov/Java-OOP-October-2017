package birthday_celebrations;

public interface Birthday {

    String getBirthDay();
}
