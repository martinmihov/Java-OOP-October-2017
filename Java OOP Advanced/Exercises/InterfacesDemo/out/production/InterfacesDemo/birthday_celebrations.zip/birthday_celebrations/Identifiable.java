package birthday_celebrations;

public interface Identifiable {

    String getId();
}
