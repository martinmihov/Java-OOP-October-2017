package collection_hierarchy;

public interface AddRemoveCollection<T> extends AddCollection<T> {

    T remove();
}
