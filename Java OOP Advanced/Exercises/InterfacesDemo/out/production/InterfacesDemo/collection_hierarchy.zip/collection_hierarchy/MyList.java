package collection_hierarchy;

public interface MyList<T> extends AddRemoveCollection<T> {

    int size();
}
