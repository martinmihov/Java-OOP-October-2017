package inferno_demo.core;

public interface Executable {
    String execute();
}
