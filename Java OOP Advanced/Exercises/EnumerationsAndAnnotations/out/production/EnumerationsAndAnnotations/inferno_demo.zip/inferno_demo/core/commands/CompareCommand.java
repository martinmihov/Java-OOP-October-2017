package inferno_demo.core.commands;

import inferno_demo.core.BaseCommand;
import inferno_demo.models.api.Weapon;

import java.util.Map;

public class CompareCommand extends BaseCommand {
    @Override
    public String execute() {
        Map<String, Weapon> weapons = super.getWeaponRepository().findAll();
        if (weapons.containsKey(super.getParams()[0]) && weapons.containsKey(super.getParams()[1])) {
            int compareIndex = weapons.get(super.getParams()[0]).compareTo(weapons.get(super.getParams()[1]));

            Weapon weapon = null;
            if (compareIndex > 0) {
                weapon = weapons.get(super.getParams()[0]);
            } else if (compareIndex < 0) {
                weapon = weapons.get(super.getParams()[1]);
            }
            if (weapon != null) {
                return String.format("%s (Item Level: %s)", weapon, weapon.getItemLevel());
            }
        }
        return null;
    }
}
