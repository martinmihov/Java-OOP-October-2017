package inferno_demo.core;

import inferno_demo.annotations.Inject;
import inferno_demo.models.api.Weapon;
import inferno_demo.repositories.Repository;

public abstract class BaseCommand implements Executable {

    @Inject
    private String[] params;
    @Inject
    private Repository<Weapon> weaponRepository;

    protected BaseCommand() {
    }

    public String[] getParams() {
        return this.params;
    }

    public Repository<Weapon> getWeaponRepository() {
        return this.weaponRepository;
    }
}
