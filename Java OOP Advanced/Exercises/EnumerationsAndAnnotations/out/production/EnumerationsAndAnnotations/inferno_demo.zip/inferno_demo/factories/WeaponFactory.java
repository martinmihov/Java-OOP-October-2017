package inferno_demo.factories;

import inferno_demo.models.api.Weapon;
import inferno_demo.models.impl.Axe;
import inferno_demo.models.impl.Knife;
import inferno_demo.models.impl.Sword;

public final class WeaponFactory {
    private WeaponFactory() {
    }

    public static Weapon createAxeWeapon(String name) {
        return new Axe(name);
    }

    public static Weapon createSwordWeapon(String name) {
        return new Sword(name);
    }

    public static Weapon createKnifeWeapon(String name) {
        return new Knife(name);
    }
}
