package inferno_demo.core.commands;

import inferno_demo.core.BaseCommand;
import inferno_demo.models.api.Weapon;

import java.util.Map;

public class AddCommand extends BaseCommand {
    @Override
    public String execute() {
        Map<String, Weapon> weapons = super.getWeaponRepository().findAll();
        if (weapons.containsKey(super.getParams()[0])) {
            weapons.get(super.getParams()[0]).addGem(super.getParams()[2], Integer.parseInt(super.getParams()[1]));
        }
        return null;
    }
}
