package custom_annotation;

@CustomAnnotation()
public class Weapon {
}
