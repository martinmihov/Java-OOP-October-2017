package cresla.utilities;

import cresla.entities.IdGenerator;

/**
 * Created by Hristo Skipernov on 12/05/2017.
 */
public final class Constants {
    public static final IdGenerator ID_GENERATOR = new IdGenerator();

    private Constants() {}
}
