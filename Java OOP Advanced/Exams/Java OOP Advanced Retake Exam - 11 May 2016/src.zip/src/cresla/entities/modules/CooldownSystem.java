package cresla.entities.modules;

/**
 * Created by Hristo Skipernov on 12/05/2017.
 */
public class CooldownSystem extends BaseAbsorbingModule {
    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
