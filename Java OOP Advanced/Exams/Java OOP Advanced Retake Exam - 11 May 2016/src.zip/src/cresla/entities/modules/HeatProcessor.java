package cresla.entities.modules;

/**
 * Created by Hristo Skipernov on 12/05/2017.
 */
public class HeatProcessor extends BaseAbsorbingModule {
    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
