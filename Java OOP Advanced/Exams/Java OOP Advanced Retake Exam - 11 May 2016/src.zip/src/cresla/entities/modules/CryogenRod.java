package cresla.entities.modules;

/**
 * Created by Hristo Skipernov on 12/05/2017.
 */
public class CryogenRod extends BaseEnergyModule{
    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
