package cresla.enums;

/**
 * Created by Hristo Skipernov on 12/05/2017.
 */
public enum ReactorType {
    CRYO,
    HEAT;
}
