package hell.entities.miscellaneous;

import hell.entities.items.CommonItem;
import hell.interfaces.Inventory;
import hell.interfaces.Item;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.Map;

import static org.mockito.Mockito.*;

public class HeroInventoryTest {

    private Inventory inventory;

    @Before
    public void init() throws NoSuchFieldException, IllegalAccessException {
        this.inventory = new HeroInventory();
        this.seedItems();
    }

    @Test
    @SuppressWarnings("unchecked")
    public void getTotalStrengthBonusShouldReturnCorrectResult() throws NoSuchFieldException, IllegalAccessException {
        //Arrange
        long expected = 2;

        //Act
        long actual = this.inventory.getTotalStrengthBonus();

        //Assert
        Assert.assertEquals("Strength is not calculate correctly", expected, actual);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void getTotalStrengthBonusShouldTestWithWrongResultWillWorkCorrectly() throws NoSuchFieldException, IllegalAccessException {
        //Arrange
        long expected = 0;

        //Act
        long actual = this.inventory.getTotalStrengthBonus();

        //Assert
        Assert.assertNotEquals("Strength is not calculate correctly", expected, actual);
    }

    @Test
    public void getTotalAgilityBonusShouldReturnCorrectResult() throws IllegalAccessException {
        //Arrange
        long expected = 2;

        //Act
        long actual = this.inventory.getTotalAgilityBonus();

        //Assert
        Assert.assertEquals("Agility is not calculate correctly", expected, actual);
    }

    @Test
    public void getTotalIntelligenceBonusShouldReturnCorrectResult() throws IllegalAccessException {
        //Arrange
        long expected = 2;

        //Act
        long actual = this.inventory.getTotalIntelligenceBonus();

        //Assert
        Assert.assertEquals("Intelligence is not calculate correctly", expected, actual);
    }

    @Test
    public void getTotalHitPointsBonus() throws IllegalAccessException {
        //Arrange
        long expected = 2;

        //Act
        long actual = this.inventory.getTotalHitPointsBonus();

        //Assert
        Assert.assertEquals("HitPoints is not calculate correctly", expected, actual);
    }

    @Test
    public void getTotalDamageBonus() throws IllegalAccessException {
        //Arrange
        long expected = 2;

        //Act
        long actual = this.inventory.getTotalDamageBonus();

        //Assert
        Assert.assertEquals("Damage is not calculate correctly", expected, actual);
    }

//    @Test
//    public void addCommonItem() throws IllegalAccessException {
//        throw new IllegalAccessException();
//    }
//
//    @Test
//    public void addRecipeItem() throws IllegalAccessException {
//        throw new IllegalAccessException();
//    }

    @SuppressWarnings("unchecked")
    private void seedItems() throws NoSuchFieldException, IllegalAccessException {
        Field commonItemsField = this.inventory.getClass().getDeclaredField("commonItems");
        commonItemsField.setAccessible(true);
        Map<String, Item> commonItems = (Map<String, Item>) commonItemsField.get(this.inventory);
        Item mock1 = mock(CommonItem.class);
        when(mock1.getStrengthBonus()).thenReturn(2);
        when(mock1.getAgilityBonus()).thenReturn(2);
        when(mock1.getDamageBonus()).thenReturn(2);
        when(mock1.getHitPointsBonus()).thenReturn(2);
        when(mock1.getIntelligenceBonus()).thenReturn(2);
        when(mock1.getName()).thenReturn("mock1");

        Item mock2 = mock(CommonItem.class);
        when(mock2.getStrengthBonus()).thenReturn(-2);
        when(mock2.getAgilityBonus()).thenReturn(-2);
        when(mock2.getDamageBonus()).thenReturn(-2);
        when(mock2.getHitPointsBonus()).thenReturn(-2);
        when(mock2.getIntelligenceBonus()).thenReturn(-2);
        when(mock2.getName()).thenReturn("mock2");

        Item mock3 = mock(CommonItem.class);
        when(mock3.getStrengthBonus()).thenReturn(2);
        when(mock3.getAgilityBonus()).thenReturn(2);
        when(mock3.getDamageBonus()).thenReturn(2);
        when(mock3.getHitPointsBonus()).thenReturn(2);
        when(mock3.getIntelligenceBonus()).thenReturn(2);
        when(mock3.getName()).thenReturn("mock3");

        commonItems.put(mock1.getName(), mock1);
        commonItems.put(mock2.getName(), mock2);
        commonItems.put(mock3.getName(), mock3);
    }
}