package hell.core;

/**
 * Created by Hristo Skipernov on 09/05/2017.
 */
public interface Executable {
    void execute() throws IllegalAccessException;
}
