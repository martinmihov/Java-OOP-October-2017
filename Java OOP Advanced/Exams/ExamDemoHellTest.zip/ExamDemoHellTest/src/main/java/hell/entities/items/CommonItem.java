package hell.entities.items;

/**
 * Created by Hristo Skipernov on 09/05/2017.
 */
public class CommonItem extends BaseItem {
    public CommonItem(String name, int strengthBonus, int agilityBonus, int intelligenceBonus, int hitPointsBonus, int damageBonus) {
        super(name, strengthBonus, agilityBonus, intelligenceBonus, hitPointsBonus, damageBonus);
    }
}
