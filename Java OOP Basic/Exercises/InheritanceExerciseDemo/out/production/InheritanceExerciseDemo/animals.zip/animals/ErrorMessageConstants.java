package animals;

public final class ErrorMessageConstants {
    public static final String INVALID_INPUT_MESSAGE = "Invalid input!";

    private ErrorMessageConstants() {
    }
}
