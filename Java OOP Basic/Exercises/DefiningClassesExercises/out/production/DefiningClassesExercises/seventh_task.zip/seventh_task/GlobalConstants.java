package seventh_task;

public final class GlobalConstants {

    public static final String DEFAULT_VALUE = "n/a";

    private GlobalConstants() {
    }
}
