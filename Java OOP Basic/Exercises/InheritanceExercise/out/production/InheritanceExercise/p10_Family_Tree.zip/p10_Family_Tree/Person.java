package p10_Family_Tree;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Person {
    private String name;
    private String birthDate;
    private List<Parent> parents;
    private List<Child> children;

    Person(String name, String date) {
        this.name = name;
        this.birthDate = date;
        this.parents = new ArrayList<>();
        this.children = new ArrayList<>();
    }

    String getName() {
        return this.name;
    }

    String getBirthDate() {
        return this.birthDate;
    }

    List<Parent> getParents() {
        return this.parents;
    }

    List<Child> getChildren() {
        return this.children;
    }

    void setName(String name) {
        this.name = name;
    }

    void addParent(Parent parent) {
        this.parents.add(parent);
    }

    void addChild(Child child) {
        this.children.add(child);
    }

    void print() {
        System.out.printf("%s %s\n", this.name, this.birthDate);
        if (parents.size() != 0) {
            System.out.println("Parents:");
            System.out.println(this.parents.stream().map(Object::toString).collect(Collectors.joining("\n")));
        } else {
            System.out.println("Parents:");
        }
        if (children.size() != 0) {
            System.out.println("Children:");
            System.out.println(this.children.stream().map(Object::toString).collect(Collectors.joining("\n")));
        } else {
            System.out.println("Children:");
        }
    }
}
