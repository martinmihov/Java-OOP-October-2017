package p10_Family_Tree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {
    private static List<String> parents = new ArrayList<>();
    private static Map<String, String> people = new LinkedHashMap<>();

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String startingValue = reader.readLine();

        String inputLine = reader.readLine();
        while (!"End".equals(inputLine)) {
            String[] tokens;
            if (inputLine.contains("-")) {
                parents.add(inputLine);
            } else {
                tokens = inputLine.split("\\s+");
                String name = tokens[0] + " " + tokens[1];
                people.putIfAbsent(name, tokens[2]);
            }
            inputLine = reader.readLine();
        }

        Map.Entry peopleEntry = people.entrySet().stream()
                .filter(p -> p.getKey().equals(startingValue) || p.getValue().equals(startingValue))
                .findFirst()
                .orElse(null);
        Person person = new Person(peopleEntry.getKey().toString(), peopleEntry.getValue().toString());

        //Checking for the main person's parents and children
        findParentsAndChildren(person);

        //Finding the rest information for the main person's parents and children
        completeFamilyMembersInfo(person);
        person.print();
    }

    private static void completeFamilyMembersInfo(Person person) {
        person.getParents().forEach(parent -> people.forEach((k, v) -> {
            if (k.equals(parent.getName())) {
                parent.setBirthDate(v);
            } else if (v.equals(parent.getBirthDate())) {
                parent.setName(k);
            }
        }));
        person.getChildren().forEach(child -> people.forEach((k, v) -> {
            if (k.equals(child.getName())) {
                child.setBirthDate(v);
            } else if (v.equals(child.getBirthDate())) {
                child.setName(k);
            }
        }));
    }

    private static void findParentsAndChildren(Person person) {
        parents.forEach(p -> {
            String[] tokens = p.split(" - ");
            String k = tokens[0];
            String v = tokens[1];

            Parent parent;
            if (v.equals(person.getBirthDate()) || v.equals(person.getName())) {
                if (isDate(k)) {
                    parent = new Parent();
                    parent.setBirthDate(k);
                } else {
                    parent = new Parent(k);
                }
                person.addParent(parent);
            } else if (k.equals(person.getName()) || k.equals(person.getBirthDate())) {
                Child child;
                if (isDate(v)) {
                    child = new Child();
                    child.setBirthDate(v);
                } else {
                    child = new Child(v);
                }
                person.addChild(child);
            }
        });
    }

    private static boolean isDate(String inputLine) {
        return Character.isDigit(inputLine.charAt(0));
    }
}