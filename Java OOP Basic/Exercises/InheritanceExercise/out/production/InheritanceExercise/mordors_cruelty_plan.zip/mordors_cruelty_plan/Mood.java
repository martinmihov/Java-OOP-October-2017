package mordors_cruelty_plan;

public class Mood {
    private int points;
}
