package online_radio_database;//package onlineradiodatabase;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.util.ArrayList;
//import java.util.List;
//
//public class Test {
//    public static void main(String[] args) throws IOException {
//        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//        int n = Integer.parseInt(reader.readLine());
//        RadioDatabase radioDb = new RadioDatabase();
//
//
//        for (int i = 0; i < n; i++) {
//            try {
//                String[] inputTokens = reader.readLine().trim().split(";");
//                String artistName = inputTokens[0];
//                String songName = inputTokens[1];
//                String[] timeTokens = inputTokens[2].trim().split(":");
//                Song song = new Song(artistName, songName, timeTokens);
//                radioDb.addSong(song);
//
//            } catch (Exception ex) {
//                System.out.println(ex.getMessage());
//            }
//        }
//        System.out.println(radioDb);
//    }
//}
//
//class RadioDatabase {
//
//    private List<Song> playList;
//    private int totalTime;
//
//    public RadioDatabase() {
//        this.playList = new ArrayList<>();
//    }
//
//    public void addSong(Song song) throws NoSuchFieldException, IllegalAccessException {
//        this.playList.add(song);
////        Field fieldTimeSeconds = song.getClass().getDeclaredField("timeSeconds");
////        fieldTimeSeconds.setAccessible(true);
//        totalTime += song.getTime(); //(int) fieldTimeSeconds.get(song);
//        System.out.println("Song added.");
//    }
//
//    private List<Song> getPlayList() {
//        return this.playList;
//    }
//
//
//    private int getTotalTime() {
//        return totalTime;
//    }
//
//    @Override
//    public String toString() {
//        StringBuilder sb = new StringBuilder();
//        int timeSeconds = this.getTotalTime();
//        int hours = timeSeconds / 3600;
//        timeSeconds %= 3600;
//        int minutes = timeSeconds / 60;
//        timeSeconds %= 60;
//        int seconds = timeSeconds;
//        sb.append(String.format("Songs added: %s%n", this.getPlayList().size()));
//        sb.append(String.format("Playlist length: %sh %sm %ss", hours, minutes, seconds));
//        return sb.toString();
//    }
//
//}
//
//class Song {
//    private String artistName;
//    private String songName;
//    private int timeSeconds;
//
//    public Song(String artistName, String songName, String[] timeTokens) {
//        this.setArtistName(artistName);
//        this.setSongName(songName);
//        this.setTime(timeTokens[0], timeTokens[1]);
//    }
//
//    public int getTime() {
//        return this.timeSeconds;
//    }
//
//    private void setTime(String minutes, String seconds) {
//        if (minutes == null || seconds == null) {
//            throw new InvalidSongLengthException(InvalidSongLengthException.INVALID_SONG_LENGTH);
//        }
//
//        int minutesInt = Integer.parseInt(minutes);
//        int secondsInt = Integer.parseInt(seconds);
//
//        if (minutesInt < 0 || minutesInt > 14) {
//            throw new InvalidSongLengthException(InvalidSongLengthException.INVALID_SONG_MINUTES);
//        }
//
//        if (secondsInt < 0 || secondsInt >= 60) {
//            throw new InvalidSongLengthException(InvalidSongLengthException.INVALID_SONG_SECONDS);
//        }
//        this.timeSeconds = (minutesInt * 60) + secondsInt;
//    }
//
//
//    private void setArtistName(String artistName) {
//        if (artistName == null) {
//            throw new InvalidSongException(InvalidSongException.INVALID_SONG);
//        }
//
//        if (artistName.length() <= 3 || artistName.length() >= 20) {
//            throw new InvalidSongException(InvalidSongException.INVALID_ARTIST_NAME);
//        }
//        this.artistName = artistName;
//    }
//
//    public void setSongName(String songName) {
//        if (songName == null) {
//            throw new InvalidSongException(InvalidSongException.INVALID_SONG);
//        }
//
//        if (songName.length() <= 3 || songName.length() >= 30) {
//            throw new InvalidSongException(InvalidSongException.INVALID_SONG_NAME);
//        }
//        this.songName = songName;
//    }
//}
//
//class InvalidSongException extends IllegalArgumentException {
//
//    public static final String INVALID_SONG = "Invalid song.";
//    public static final String INVALID_ARTIST_NAME = "Artist name should be between 3 and 20 symbols.";
//    public static final String INVALID_SONG_NAME = "Song name should be between 3 and 30 symbols.";
//
//    public InvalidSongException(String message) {
//        super(message);
//    }
//}
//
//class InvalidSongLengthException extends InvalidSongException{
//    public static final String INVALID_SONG_LENGTH = "Invalid song length.";
//    public static final String INVALID_SONG_MINUTES = "Song minutes should be between 0 and 14.";
//    public static final String INVALID_SONG_SECONDS = "Song seconds should be between 0 and 59.";
//
//
//    public InvalidSongLengthException (String message) {
//        super(message);
//    }
//}
//
//
//
///*
//Input 1:
//3
//ABBA;Mamma Mia;3:35
//Nasko Mentata;Shopskata salata;4:123
//Nasko Mentata;Shopskata salata;4:12
//
//Expected output 1:
//Song added.
//Song seconds should be between 0 and 59.
//Song added.
//Songs added: 2
//Playlist length: 0h 7m 47s
//
//
//Input 2:
//5
//Nasko Mentata;Shopskata salata;14:59
//Nasko Mentata;Shopskata salata;14:59
//Nasko Mentata;Shopskata salata;14:59
//Nasko Mentata;Shopskata salata;14:59
//Nasko Mentata;Shopskata salata;0:5
//
//Expected output 2:
//Song added.
//Song added.
//Song added.
//Song added.
//Song added.
//Songs added: 5
//Playlist length: 1h 0m 1s
//
//
// */