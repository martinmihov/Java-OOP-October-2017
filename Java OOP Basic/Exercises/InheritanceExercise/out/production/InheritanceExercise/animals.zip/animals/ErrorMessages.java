package animals;

public final class ErrorMessages {
    public static final String INVALID_INPUT_ERROR_MESSAGE = "Invalid input!";

    private ErrorMessages() {}
}
