package PetClinics;

import PetClinics.Pet;

public interface Room {

    void add(Pet pet);

    boolean isEmpty();

    void release();
}
