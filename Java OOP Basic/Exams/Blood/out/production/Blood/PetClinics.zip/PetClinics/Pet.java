package PetClinics;

public interface Pet {
}
