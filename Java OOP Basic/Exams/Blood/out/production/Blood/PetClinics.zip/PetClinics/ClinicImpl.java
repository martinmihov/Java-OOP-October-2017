package PetClinics;

import java.util.Iterator;

public class ClinicImpl implements Clinic,Iterable<Room> {
    private String name;
    private Room[] rooms;
    private Iterator<Room> accomodationIterator;
    private Iterator<Room> releaseIterator;

    public ClinicImpl(String name,int numberOfRooms) {
        this.name = name;
        setRooms(numberOfRooms);
        this.accomodationIterator = new AccomodationIterator();
        this.releaseIterator = new ReleaseIterator();
    }

    @Override
    public boolean addPet(Pet pet) {
        while(accomodationIterator.hasNext()){
            Room room = accomodationIterator.next();
            if (room == null){
                room = new RoomImpl();
                room.add(pet);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean release() {
        while (releaseIterator.hasNext()){
            Room room = releaseIterator.next();
            if (room != null){
                room.release();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean hasEmptyRooms() {
        for (Room room : rooms) {
            if (room == null){
                return true;
            }
        }
        return false;
    }

    @Override
    public void print() {
        for (Room room : rooms) {
            if (room == null){
                System.out.println("Room empty");
            }
            else {
                System.out.println(room);
            }
        }
    }

    @Override
    public void printRoom(int numberOfTheRoom) {
        Room room = rooms[numberOfTheRoom - 1];
        if (room == null){
            System.out.println("Room empty");
        }
        else {
            System.out.println(room);
        }
    }

    private void setRooms(int numberOfRooms) {
        if (numberOfRooms % 2 == 0){
            throw new IllegalArgumentException("Invalid Operation!");
        }
        else{
            this.rooms = new Room[numberOfRooms];
        }
    }

    @Override
    public Iterator<Room> iterator() {
        return new PrintIterator();
    }

    private final class PrintIterator implements Iterator<Room>{

        int index = 0;
        @Override
        public boolean hasNext() {
            return index < rooms.length;
        }

        @Override
        public Room next() {
            return rooms[index++];
        }
    }

    private final class AccomodationIterator implements Iterator<Room> {
        int index = rooms.length / 2;
        int counterLeft = index - 1;
        int counterRight = index + 1;

        @Override
        public boolean hasNext() {
            return rooms.length != 1 && counterLeft >= 0 && counterRight < rooms.length;
        }


        @Override
        public Room next() {
            if (rooms[counterLeft] != null && rooms[counterRight] != null && rooms[index] != null){
                counterRight++;
                counterLeft++;
            }
            if (rooms[index] == null){
                return rooms[index];
            }
            if (rooms[counterLeft] == null){
                return rooms[counterLeft];
            }
            else {
                return rooms[counterRight];
            }
        }
    }

    private final class ReleaseIterator implements  Iterator<Room> {

        int index = rooms.length / 2;
        boolean continueLooping = true;
        @Override
        public boolean hasNext() {
            return continueLooping;
        }

        @Override
        public Room next() {
            for (int i = index; i < rooms.length; i++) {
                if (rooms[i] != null){
                    continueLooping = false;
                    return rooms[i];
                }
            }
            for (int i = 0; i < index; i++) {
                if (rooms[i] != null){
                    continueLooping = false;
                    return rooms[i];
                }
            }
            continueLooping = false;
            return null;
        }
    }
}
