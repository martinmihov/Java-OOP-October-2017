package _07_FoodShortage.interfaces;


public interface Birthday {
    String getBirthday();
}

