package _07_FoodShortage.interfaces;

public interface Buyer {
    void buyFood();
    int getFood();
}
